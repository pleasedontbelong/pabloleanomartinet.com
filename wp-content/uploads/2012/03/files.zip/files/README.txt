Visit
http://www.pabloleanomartinet.com/cakephp-2-0-compressing-js-and-css-using-ccss-or-yuicompressor/

for more explanation on how to use this files